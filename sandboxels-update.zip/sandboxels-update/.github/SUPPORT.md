Controls for Sandboxels are listed underneath [the game](https://sandboxels.R74n.com).

Join our [Discord server](https://discord.gg/ejUc6YPQuS) for support, suggestions, or bug reports.

You can also report issues on this GitHub repository [here](https://github.com/R74nCom/sandboxels/issues).

For help with creating mods, there's a channel on the Discord for that!

For help with specific mods, the mod's creator is likely in the Discord. Ask around and you'll be directed to them.
