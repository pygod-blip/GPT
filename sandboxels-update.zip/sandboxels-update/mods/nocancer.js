elements.cancer.behavior = [
  "XX|XX|XX",
  "XX|DL|XX",
  "XX|XX|XX"
]
elements.cancer.color = "#000000";
window.addEventListener("load", ()=>{
  if(!settings.cheerful)document.getElementById("elementButton-cancer").remove();
})
