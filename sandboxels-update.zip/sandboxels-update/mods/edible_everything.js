window.addEventListener('load', function() {
	for (element in elements) {
		elements[element].isFood = true;
	}
});